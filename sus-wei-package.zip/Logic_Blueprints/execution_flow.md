# SUS-Script Execution Flow
1. Input Analysis
2. Execution Auto-Selection
3. Structuring & Debugging
4. Refinement Loop
5. Output Delivery
